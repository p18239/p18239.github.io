webd 网盘

下载地址
http://mydisk.ml:5156/webd-win32.7z (Windows 平台)
http://mydisk.ml:5156 (同时为只读演示地址)
http://webdisk.ys168.com (备用)

预览图
https://imgurl.org/temp/1810/479a95ce0a8d6fb7.png
https://imgurl.org/temp/1810/f5ef062247dd9d3c.png

介绍:
  这是一个极轻量级的用于自己搭建简易网盘的软件
  解压后不同平台的程序文件只有 60 KB 至 90 KB, 包含前后端和服务器
  可以完成文件上传下载, 手机在线看电影的功能, 亦可拍摄视频照片后自动上传分享与其它用户.
  支持 Windows、Linux、甚至 OpenWrt 路由器平台
  还有高性能高并发的特性(采用 IOCP 和 epoll)，可承担大量用户同时使用

使用说明

Windows 平台安装方法, 需 Win7 或更高版本, 本软件为绿色版，解压后即可使用。
  1. 下载文件名包含 win32 的压缩包(64位Windows亦可用), 例如 http://mydisk.ml:5156/webd-win32.tar.gz

  2. 用 7zip、winrar 等工具把下载的文件解压到适当的目录

  3. 进入解压到的目录:
    1) webd.exe 为主程序, 可直接双击运行，运行后在状态栏有图标。
    2) tools.cmd 运行后有个简易的菜单界面, 用于控制开机启动和桌面快捷方式, 右键管理员运行时可以控制防火墙.

使用方法:
  1. 启动后双击状态栏图标, 默认浏览器会打开本软件的界面, 支持 Chrome FireFox 和大部分手机上的浏览器, IE 可能会空白.
     Chrome 下载地址 https://tools.shuax.com/chrome/

  2. 用手机打开浏览器地址栏的地址, 可以在手机上使用

  3. web 界面上的 New 用于新建文件夹

  4. 按 Upload 会弹出选择文件对话框
     可选中多个文件上传, 上传过程中有进度显示, 可以上传很大的文件.
	 部分手机可以长按文件名进入多选模式, 但有的手机系统不支持
	 手机上还可以选择拍照或录像后自动上传, 之后其它设备可以在线观看.

  5. 删除文件: 单击列表中文件名之外的位置进行选中, 选中的文件名有下划线, 选中一个或多个后可以删除
     (文件不会真正从系统删除，而是位于 web 目录下的 .Trash 文件夹内)
	 移动文件: 选中文件后点 Cut, 然后转到目标目录点 Paste 

  6. 浏览器支持的视频比如 mp4、flv 等, 可以在手机或桌面浏览器内直接观看.

  7. 浏览器不支持的视频, 可以复制链接后用其它播放器(例如 mxplayer)播放.

高级使用方法:
  1. 虚拟目录
     软件本身不支持虚拟目录, 但可以用操作系统的目录链接功能变相实现.
	 比如软件位于 C:\webd , web 目录默认就是 C:\webd\web , 那么如果要通过 web 界面访问 F:\dir2 可如下操作:
	   右键编辑 MakeLink.cmd 进行编辑脚本
	   在文件中的 pause 前面一行添加以下内容并保存关闭.
	   mklink /D C:\webd\web\dir2 F:\dir2
	   然后右键管理员运行这个文件, 即可创建目录链接

  2. 在文件列表中隐藏某个文件或文件夹，只要命令行下把某个文件重名名成点 . 开头的即可隐藏
     比如 cmd 命令窗口下运行:
	   cd /d f:\dir2
	   move xxxx .xxxx

  3. 更改默认的 9212 端口, 在 webd 快捷方式那里, 右键属性,
     在目标那栏添最后 加个空格 然后加 -l 9900 即可更改端口, 注意原来的内容不要去掉
	 (注意有桌面和 开始 -> 所有程序 -> 启动 两个地方的快捷方式)

  4. 更改默认的 web 目录, 同 4 中的方法, 添加 -w E:\ 即可使用整个 E 盘作为 web目录

  5. 隐藏状态栏图标, 同 4 中的方法, 添加 -h
	 

Linux 和 OpenWrt 的安装方法:

  文件名包含 linux-x86_64 的压缩包适用于平常的 Linux 发行版, 需要内核 3.15 以及以上, glibc 2.17 以及以上.
  文件名包含其它内容的为 OpenWrt 版本, 其中带 cc 的适用于 Openwrt Chaos Calmer 15.05.1 , 不带 cc 的适用于最新版.
  
  目前支持的几个大种类有:
    OpenWrt: ar71xx bcm53xx ipq40xx ipq806x kirkwood ramips/mt7620 ramips/mt7621 mvebu_cortexa9 oxnas x86_64 xrx200
    Linux: arm armv8l arm_aarch64 x86_64

  如合判断使用哪个版本的webd ?
    固件位于此列表 https://downloads.openwrt.org/snapshots/targets/ramips/mt7621/ 则用 mt7621 的版本
    固件位于此列表下面的子列表 https://downloads.openwrt.org/snapshots/targets/ar71xx/ 则用 ar71xx 的版本

    还可以在这里 https://downloads.openwrt.org/snapshots/targets/ 直接查找对应的硬件列表
    即使不在列表中, 如果CPU一样且所用固件是从 OpenWrt 修改而来的, 也一样能支持.
    作者没有那么多的硬件来组合各处不同的固件一一测试, 请自行尝试运行, 然后反馈到论坛或发邮件 zhngq2312@gmail.com

  安装过程:
    以普通 linux 发行版为例,
	通过 ssh、串口、或者本地控制台进入命令界面
	cd /tmp
	wget http://mydisk.ml:5156/.lastest/webd-linux-x86_64.tar.gz
	tar -xzvf webd-linux-x86_64.tar.gz
	/tmp/webd/webd -w /tmp/webd/web # 这里会停住并显示一些日志

	用浏览器打开路由器或 linux 机器对应的IP加端口, 比如 http://192.168.11.1:9212 就能看到web界面了.

	如果要后台运行并且每次开机都能自动启动, 回到刚才的命令界面按 Ctrl+C 关闭刚才的进程
	mkdir -pv /srv/webd
	mv -fv /tmp/webd/webd /usr/bin
	mv -fv /tmp/webd/web /srv/webd
	# rm -r /tmp/webd /tmp/webd-linux-x86_64.tar.gz # 可选, 删除不用的文件
	
	然后编辑 /etc/rc.local 添加以下内容, 并运行一次以下内容以便立即生效
	/usr/bin/webd -l 9212 -w /srv/webd/web &>/dev/null &
	端口和路径都可以直接更改的.
	(当然也可以写 init 启动脚本或 systemd 启动文件)

	如果要访问的文件不在 /srv/webd/web 下面怎么办呢, 可以创建符号连接, 比如:
	  ln -sv /mnt/sda1 /srv/webd/web

	如果使用了 padavan 等不能运行这个程序的固件可以尝试用 chroot 方法运行
	以下操作要保证路由器 CPU 类型兼容
	去 https://downloads.openwrt.org/snapshots/targets/ 下载对应的 *squashfs-sysupgrade.bin 字样的镜像
	用 7zip 打开镜像进入 lib 目录, 解压 libc.so libgcc_s.so.1 , 记下 ld-musl-*.so.1 字样的文件名
	使目录结构类似如下:
	  /tmp/webd/webd # 本程序
	  /tmp/webd/lib/libgcc_s.so.1
	  /tmp/webd/lib/libc.so # 该文件用 chmod +x libc.so 增加可执行权限
	  /tmp/webd/lib/ld-musl-*.so.1 # 实际文件名为刚才记下的文件名, 该文件为 libc.so 的符号连接
	  cd /tmp/webd/lib; ln -sv libc.so ld-musl-*.so.1
	然后 chroot /tmp/webd /webd 即可运行。

	注意路径参数要把 /tmp/webd 当成新的 root
	  比如原来的运行方式是 /tmp/webd/webd -w /tmp/webd/web
	  那么新的运行方式为 chroot /tmp/webd /webd -w /web
	  其中通过符号连接到 /tmp/webd 内的文件无法访问, 但是硬连接或 mount --bind 的目录可以使用.
	

by zhngq2312@gmail.com
